package program1;

public class JavaMethods {
	public int add_numbers()
	{
		int a = 10;
		int b = 20;
		int sum = a+b;
		return sum;
	}
	public double area_circle(){
		int radius = 5;
		double area = 3.14*radius*radius;
		return area;
	}
	public void area_rectangle(){
		int l=10;
		int w=30;
		int rec=l*w;
		System.out.println("area of rectangle is"+rec);
	}
	public int area_square(){
		int a=10;
		int square=a*a;
		return square;
		
	}
	
	

public static void main(String[] args)
{
	JavaMethods s=new JavaMethods();
	JavaMethods d=new JavaMethods();
	JavaMethods e=new JavaMethods();
	JavaMethods f=new JavaMethods();
	int res = s.add_numbers();
	double res1 = d.area_circle();
	int res2=f.area_square();
	e.area_rectangle();
	System.out.println(res);
	System.out.println(res1);
	System.out.println(res2);
	
	
	
	
	
}
}
